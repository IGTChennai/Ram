package retailerManagement;

import java.io.IOException;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import java.util.stream.IntStream;

import org.apache.commons.math3.genetics.RandomKey;
import org.apache.commons.math3.random.RandomDataGenerator;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.RandomGeneratorFactory;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.junit.After;
import org.junit.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByTagName;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import com.graphbuilder.math.func.RandFunction;

public class RetailerCreation 
{
	//System.setProperty("webdriver.chrome.driver","C:\\Ramkumar\\Automation - Aug 2019\\chromedriver_win32\\chromedriver.exe");	
	public static WebDriver wd=new ChromeDriver();
	public static WebElement element;
	
	@Test
	public void Creation() throws InterruptedException, IOException
	{
			XSSFWorkbook wb=new XSSFWorkbook("C:\\Ramkumar\\Automation - Aug 2019\\RetailerCreation.xlsx");
			XSSFSheet sh=wb.getSheet("Users");
			int r=sh.getLastRowNum();
			System.out.println("Total # of Rows: "+r);
	    	Thread.sleep(5000);
			//WebDriver wd=new ChromeDriver();
			wd.manage().window().maximize();
			Thread.sleep(5000);
			wd.get("https://xxmkt1422/navigator/#/login");
			Thread.sleep(8000);
			navigatorLogin(wd,sh);
			Thread.sleep(5000);
			System.out.println("Total # of Rows in "+ sh + r);
			wd.findElement(By.id("side-menu-button-4000")).click();
			Thread.sleep(2000);
			wd.findElement(By.id("side-menu-button-4020")).click();
			Thread.sleep(2000);
			wd.findElement(By.id("independent-retailer-application")).click();
			Thread.sleep(2000);
			sh=wb.getSheet("LocationInfo");
			//System.out.println("Total # of Rows in "+ sh1 + r);
			retailerLocationInfo(wd,sh);
			//r=sh1.getLastRowNum();		
			Thread.sleep(5000);
			sh=wb.getSheet("BusinessDetails");
			retailerBusinessDetails(wd,sh);
			sh=wb.getSheet("Owners");
			retailerOwners(wd,sh);
			sh=wb.getSheet("LocationInfo");
			retailerLocationContacts(wd,sh);
			sh=wb.getSheet("LocationInfo");
			retailerBanking(wd,sh);
			sh=wb.getSheet("LocationInfo");
			retailerComplianceChecks(wd,sh);
			//wb.close();
	
	}	
	public void navigatorLogin(WebDriver wd,XSSFSheet sh) throws InterruptedException
	{
		//Navigator Login
		wd.findElement(By.id("auth-login-page-button")).click();
		Thread.sleep(2000);
		wd.findElement(By.name("j_username")).sendKeys(sh.getRow(1).getCell(0).getStringCellValue());
		wd.findElement(By.name("j_password")).sendKeys(sh.getRow(1).getCell(1).getStringCellValue());
		Thread.sleep(2000);
		wd.findElement(By.id("auth-login-page-button")).click();
		Thread.sleep(5000);
	}
	public void retailerLocationInfo(WebDriver wd,XSSFSheet sh) throws InterruptedException
	{
		wd.findElement(By.name("locationName")).sendKeys(sh.getRow(1).getCell(0).getStringCellValue());
		//wd.findElement(By.name("retailerId")).sendKeys(sh.getRow(1).getCell(1).getStringCellValue());
		Thread.sleep(3000);
		WebElement w;
		Select s;
		System.out.println("success");
		w=wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-es-field-3-select-adaCode"));
		s=new Select(w);
		s.selectByIndex(3);
		Thread.sleep(3000);
		w=wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-es-field-4-select-adaAuditCode"));
		s=new Select(w);
		System.out.println(sh);
		s.selectByIndex(3);
		Thread.sleep(3000);
		wd.findElement(By.name("phoneNumber")).sendKeys(sh.getRow(1).getCell(4).getStringCellValue());
		Thread.sleep(3000);
		wd.findElement(By.name("emailAddress")).sendKeys(sh.getRow(1).getCell(5).getStringCellValue());
		Thread.sleep(5000);
		WebElement element=wd.findElement(By.name("md-autocomplete-input-line1"));
		scrollToVisibleElement(element);
		//JavascriptExecutor js = (JavascriptExecutor) wd;
		//js.executeScript("arguments[0].scrollIntoView();", element);
		Thread.sleep(5000);
		wd.findElement(By.name("md-autocomplete-input-line1")).sendKeys(sh.getRow(1).getCell(6).getStringCellValue());
		Thread.sleep(2000);
		w=wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-es-address-form-es-panel-body-es-panel-body-es-field-10-select-county"));
		s=new Select(w);
		s.selectByIndex(2);
		Thread.sleep(2000);
		wd.findElement(By.name("city")).sendKeys(sh.getRow(1).getCell(7).getStringCellValue());
		Thread.sleep(5000);		
		Double arg0=sh.getRow(1).getCell(8).getNumericCellValue();
		wd.findElement(By.name("postalCode")).sendKeys(arg0.toString());
		Thread.sleep(5000);
		element=wd.findElement(By.xpath("//input[@es-bdd-id='rs-application-location-page-rs-application-location-form-2-es-panel-body-es-address-form-es-panel-body-es-panel-body-es-field-4-es-address-form-coordinates-input']"));
		scrollToVisibleElement(element);
		Thread.sleep(3000);
		wd.findElement(By.xpath("//input[@es-bdd-id='rs-application-location-page-rs-application-location-form-2-es-panel-body-es-address-form-es-panel-body-es-panel-body-es-field-4-es-address-form-coordinates-input']")).sendKeys(sh.getRow(1).getCell(9).getStringCellValue());
		Thread.sleep(3000);
		element=wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-2-es-business-week-es-business-hours-button"));
		Thread.sleep(3000);
		scrollToVisibleElement(element);
		//js.executeScript("arguments[0].scrollIntoView();", element);
		Thread.sleep(3000);	
		wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-2-es-business-week-es-business-hours-button")).click();
		Thread.sleep(2000);
		wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-2-es-business-week-es-business-hours-button-4")).click();
		Thread.sleep(2000);
		wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-2-es-business-week-es-business-hours-button-2")).click();
		Thread.sleep(2000);
		wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-2-es-business-week-es-business-hours-button-9")).click();
		Thread.sleep(2000);
		wd.findElement(By.id("rs-application-location-page-rs-application-location-form-2-es-panel-body-2-es-business-week-es-business-hours-button-3")).click();
		Thread.sleep(3000);
		wd.findElement(By.id("rs-application-ui-es-floating-action-bar-rs-application-action-bar-button-2")).click();
		Thread.sleep(2000);
	}
	public void retailerBusinessDetails(WebDriver wd,XSSFSheet sh) throws InterruptedException
	{
		try
		{
			int rand;
			rand=randGenDigits(3,1);
			WebElement w=wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-es-field-2-select-taxCode"));		
			Select s=new Select(w);
			s.selectByIndex(rand);
			Thread.sleep(1000);
			wd.findElement(By.name("fedTaxId")).sendKeys(randomNumberGenerator());
			Thread.sleep(1000);
			wd.findElement(By.name("taxName")).sendKeys(randomNumberGenerator());
			Thread.sleep(2000);
			element=wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-rs-business-form-tax-conflicts-2-rs-tax-conflicting-locations-button"));
			scrollToVisibleElement(element);
			Thread.sleep(3000);
			wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-rs-business-form-tax-conflicts-2-rs-tax-conflicting-locations-button")).click();
			Thread.sleep(5000);
			String str= wd.findElement(By.xpath("//*[text()='No conflicting retailers has been found']")).getText();
			if(str.equals("No conflicting retailers has been found"))
			{
				System.out.println("No conflicting retailers has been found");
			}
			Thread.sleep(3000);
			w=wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-2-es-field-select-tradeChannelType"));
			s=new Select(w);
			rand=randGenDigits(5,1);
			s.selectByIndex(rand);
			Thread.sleep(3000);
			w=wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-2-es-field-3-select-sicType"));
			s=new Select(w);
			s.selectByIndex(1);
			Thread.sleep(2000);
			wd.findElement(By.name("dunsNumber")).sendKeys(randGenDigits(3,1) + "");
			Thread.sleep(2000);
			w=wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-2-es-field-4-select-ownershipType"));
			s=new Select(w);
			s.selectByIndex(randGenDigits(8,1));
			Thread.sleep(2000);
			w=wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-2-es-field-6-select-contractType"));
			s=new Select(w);
			s.selectByIndex(randGenDigits(3,1));
			wd.findElement(By.id("rs-application-ui-es-floating-action-bar-rs-application-action-bar-button-2")).click();
			Thread.sleep(3000);
		}
		catch (Exception e) 
		{
			Thread.sleep(5000);
			wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-rs-business-form-tax-conflicts-2-rs-tax-conflicting-locations-md-checkbox")).click();
			Thread.sleep(5000);
			wd.findElement(By.id("rs-application-business-page-es-panel-body-rs-business-form-es-panel-body-rs-business-form-tax-conflicts-button")).click();
		}
		
		//Random r=new Random();
		//int i=r.nextInt(899999999) + 200000000;
		//System.out.println("Random Number"+ i);
		//System.out.println("Random Number"+ Math.random());
		//System.out.println("Random Number"+ ThreadLocalRandom.current().nextInt());
	}

	public void retailerOwners(WebDriver wd,XSSFSheet sh) throws InterruptedException
	{
		Thread.sleep(3000);
		wd.findElement(By.id("assign-owner-button")).click();
		Thread.sleep(2000);
		wd.findElement(By.name("nationalIdNumber")).sendKeys(randomNumberGenerator());
		Thread.sleep(2000);
		wd.findElement(By.id("search-owner-by-nin-button")).click();
		Thread.sleep(5000);
		element=wd.findElement(By.name("firstName"));
		scrollToVisibleElement(element);
		Thread.sleep(2000);
		wd.findElement(By.name("firstName")).sendKeys(sh.getRow(1).getCell(0).getStringCellValue());
		Thread.sleep(2000);
		wd.findElement(By.name("lastName")).sendKeys(sh.getRow(1).getCell(1).getStringCellValue());
		Thread.sleep(2000);
		WebElement w;
		element=wd.findElement(By.name("gender"));
		scrollToVisibleElement(element);
		//w=wd.findElement(By.name("gender"));
		Select s=new Select(element);
		s.selectByValue(sh.getRow(1).getCell(2).getStringCellValue());
		Thread.sleep(2000);
		wd.findElement(By.name("phoneNumber")).sendKeys(sh.getRow(1).getCell(3).getStringCellValue());
		Thread.sleep(2000);
		wd.findElement(By.name("emailAddress")).sendKeys(sh.getRow(1).getCell(4).getStringCellValue());
		element=wd.findElement(By.name("upperPostalCode"));
		scrollToVisibleElement(element);
		wd.findElement(By.name("md-autocomplete-input-line1")).sendKeys(sh.getRow(1).getCell(5).getStringCellValue());
		Thread.sleep(2000);
		wd.findElement(By.name("postalCode")).sendKeys(sh.getRow(1).getCell(6).getStringCellValue());	
	}
	public void retailerLocationContacts(WebDriver wd,XSSFSheet sh)
	{
		
	}
	public void retailerBanking(WebDriver wd,XSSFSheet sh)
	{
		
	}
	public void retailerComplianceChecks(WebDriver wd,XSSFSheet sh)
	{
		
	}
	public void scrollToVisibleElement(WebElement element)
	{
		//WebElement element=wd.findElement(By.name("md-autocomplete-input-line1"));
		JavascriptExecutor js = (JavascriptExecutor) wd;
		js.executeScript("arguments[0].scrollIntoView();", element);
	}
	public String randomNumberGenerator()
	{
		Random r=new Random();
		return r.nextInt(899999999) + 100000000 + "";
		//System.out.println("Random Number"+ i);
		//System.out.println("Random Number"+ Math.random());
		//System.out.println("Random Number"+ ThreadLocalRandom.current().nextInt());
	}
	public int randGenDigits(int x,int y)
	{
		int random = x-((int)Math.round((Math.random())*(x-y)));
		return random;
	}
	@After
	public void close()
	{
		wd.close();
	}
}
