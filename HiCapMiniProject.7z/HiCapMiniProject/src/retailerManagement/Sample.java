package retailerManagement;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=7,y=2;
		int random = x-((int)Math.round((Math.random())*(x-y)));
		System.out.println("Random number between 2 to 3: "+  random);
	}

}
